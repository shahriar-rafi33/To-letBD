package classes;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import classes.*;

public class AddHome implements ActionListener {
    private Container c;
    private JFrame frame;
    private JLabel type;
    private JLabel size;
    private JLabel HomeNo;
    private JLabel rent;
    private JLabel place;
    private JLabel max;
    private JLabel imgLabel2;

    private JTextField attach;
    private JTextField typeField;
    private JTextField rentField;
    private JTextField sizeField;
    private JTextField HomeField;
    private JTextField placeField;

    private JButton exitButton;
    private JButton attachButton;
    private JButton submitButton;
    private JButton backButton;
    private JButton logoutButton;

    private JPanel panel;

    private Cursor cursor;

    public AddHome() {

        frame = new JFrame();
        frame.setBounds(50, 50, 1200, 780);
        frame.setTitle("Add House");
        frame.setLayout(null);
        frame.setVisible(true);
        c = frame.getContentPane();
        c.setBackground(Color.decode("#FAF9F6"));
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ImageIcon icon = new ImageIcon("images/In apartment.png");
        frame.setIconImage(icon.getImage());
        frame.setLocationRelativeTo(null);

        cursor = new Cursor(Cursor.HAND_CURSOR);

        panel = new JPanel();
        panel.setBounds(885,180, 260, 260);
        panel.setLayout(null);
        panel.setVisible(true);
        panel.setBackground(new Color(255,255,224));
        c.add(panel);

        JLabel add = new JLabel("Add House Details");
        add.setBounds(800, 20, 200, 30);
        Font addFont = new Font("Times New Roman", Font.BOLD, 22);
        add.setFont(addFont);
        add.setForeground(new Color(153,0,0));
        frame.add(add);

        type = new JLabel("Type :");
        type.setBounds(600, 100, 150, 50);
        Font typeFont = new Font("Times New Roman", Font.PLAIN, 20);
        type.setFont(typeFont);
        type.setForeground(new Color(153,0,0));
        frame.add(type);

        typeField = new JTextField();
        typeField.setBounds(600, 150, 236, 30);
        Font userfieldFont = new Font("Verdana", Font.PLAIN, 17);
        typeField.setFont(userfieldFont);
        typeField.setOpaque(false);
        typeField.setForeground(new Color(204,0,0));
        typeField.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder1 = BorderFactory.createMatteBorder(0, 0, 2, 0,new Color(204,0,0));
        typeField.setBorder(redBorder1);
        frame.add(typeField);

        place = new JLabel("Place :");
        place.setBounds(600, 200, 150, 50);
        Font fullNameFont = new Font("Times New Roman", Font.PLAIN, 20);
        place.setFont(fullNameFont);
        place.setForeground(new Color(153,0,0));
        frame.add(place);

        placeField = new JTextField();
        placeField.setBounds(600, 250, 236, 30);
        Font fullFieldFont = new Font("Verdana", Font.PLAIN, 17);
        placeField.setFont(fullFieldFont);
        placeField.setOpaque(false);
        placeField.setForeground(new Color(204,0,0));
        placeField.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder = BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204,0,0));
        placeField.setBorder(redBorder);
        frame.add(placeField);

        size = new JLabel("Size :");
        size.setBounds(600, 300, 150, 50);
        Font passwordFont = new Font("Times New Roman", Font.PLAIN, 20);
        size.setFont(passwordFont);
        size.setForeground(new Color(153,0,0));
        frame.add(size);

        sizeField = new JTextField();
        sizeField.setBounds(600, 350, 236, 30);
        Font passfieldFont = new Font("Verdana", Font.PLAIN, 17);
        sizeField.setFont(passfieldFont);
        sizeField.setOpaque(false);
        sizeField.setForeground(new Color(204,0,0));
        sizeField.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder3 = BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204,0,0));
        sizeField.setBorder(redBorder3);
        frame.add(sizeField);

        HomeNo = new JLabel("House No :");
        HomeNo.setBounds(600, 400, 200, 50);
        Font cconfpasswordFont = new Font("Times New Roman", Font.PLAIN, 20);
        HomeNo.setFont(cconfpasswordFont);
        HomeNo.setForeground(new Color(153,0,0));
        frame.add(HomeNo);

        HomeField = new JTextField();
        HomeField.setBounds(600, 450, 236, 30);
        Font confpassFieldFont = new Font("Verdana", Font.PLAIN, 17);
        HomeField.setFont(confpassFieldFont);
        HomeField.setOpaque(false);
        HomeField.setForeground(new Color(204,0,0));
        HomeField.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder4 = BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204,0,0));
        HomeField.setBorder(redBorder4);
        frame.add(HomeField);

        rent = new JLabel("Rent per month :");
        rent.setBounds(600, 500, 150, 50);
        Font emailFont = new Font("Times New Roman", Font.PLAIN, 20);
        rent.setFont(emailFont);
        rent.setForeground(new Color(153,0,0));
        frame.add(rent);

        rentField = new JTextField();
        rentField.setBounds(600, 550, 236, 30);
        Font emailFieldFont = new Font("Verdana", Font.PLAIN, 17);
        rentField.setFont(emailFieldFont);
        rentField.setOpaque(false);
        rentField.setForeground(new Color(204,0,0));
        rentField.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder2 = BorderFactory.createMatteBorder(0, 0, 2, 0,new Color(204,0,0));
        rentField.setBorder(redBorder2);
        frame.add(rentField);

        JLabel addPhoto = new JLabel("Add a photo here ");
        addPhoto.setBounds(940, 135, 150, 30);
        Font addPhotoFont = new Font("Times New Roman", Font.BOLD, 17);
        addPhoto.setFont(addPhotoFont);
        addPhoto.setForeground(new Color(153,0,0));
        frame.add(addPhoto);

        max = new JLabel("Max Photo Size 260 * 260");
        max.setBounds(990, 435, 150, 30);
        Font maxFont = new Font("Times New Roman", Font.PLAIN, 11);
        max.setFont(maxFont);
        max.setForeground(new Color(153,0,0));
        frame.add(max);

        attach = new JTextField();
        attach.setBounds(800, 365, 220, 30);
        Font attachFont = new Font("Verdana", Font.PLAIN, 17);
        attach.setFont(attachFont);
        attach.setOpaque(false);
        attach.setForeground(new Color(153,0,0));
        attach.setBorder(BorderFactory.createEmptyBorder());
        Border redBorder5 = BorderFactory.createMatteBorder(0, 0, 0, 0, new Color(204,0,0));
        attach.setBorder(redBorder5);
        frame.add(attach);

        attachButton = new JButton("Attachment");
        attachButton.setBounds(890, 480, 100, 30);
        attachButton.setBackground(new Color(240,230,140));
        attachButton.setForeground(new Color(153,0,0));
        Font attachButtonFont = new Font("Times New Roman", Font.BOLD, 15);
        attachButton.setFont(attachButtonFont);
        attachButton.setCursor(cursor);
        attachButton.setBorder(BorderFactory.createEmptyBorder());
        frame.add(attachButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(1050, 480, 100, 30);
        submitButton.setBackground(new Color(240,230,140));
        submitButton.setForeground(new Color(153,0,0));
        Font submitButtonFont = new Font("Times New Roman", Font.BOLD, 15);
        submitButton.setFont(submitButtonFont);
        submitButton.setCursor(cursor);
        submitButton.setBorder(BorderFactory.createEmptyBorder());
        frame.add(submitButton);

        ImageIcon exit = new ImageIcon("images/in Exit.png");
        exitButton = new JButton(exit);
		exitButton.setToolTipText("Exit");
        exitButton.setBounds(1100, 650, exit.getIconWidth(), exit.getIconHeight());
        exitButton.setBackground(Color.black);
        exitButton.setOpaque(false);
        exitButton.setBorder(BorderFactory.createEmptyBorder());
        frame.add(exitButton);

        ImageIcon backimg = new ImageIcon("images/in previous.png");
        backButton = new JButton(backimg);
		backButton.setToolTipText("Back");
        backButton.setBounds(600, 670, backimg.getIconWidth(), backimg.getIconHeight());
        backButton.setBackground(Color.black);
        backButton.setOpaque(false);
        backButton.setBorder(BorderFactory.createEmptyBorder());
        frame.add(backButton);

        

        imgLabel2 = new JLabel();
        panel.add(imgLabel2);
		
		ImageIcon background=new ImageIcon("images/in addhouse.jpg");
        Image img=background.getImage();
        Image temp=img.getScaledInstance(570,780,Image.SCALE_SMOOTH);
        background=new ImageIcon(temp);
        JLabel back=new JLabel(background);
        back.setLayout(null);
        back.setBounds(0,0,570,780);
		frame.add(back);

        submitButton.addActionListener(this);
        attachButton.addActionListener(this);
        backButton.addActionListener(this);
        exitButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        String type1 = typeField.getText();
        String size1 = sizeField.getText();
        String rent1 = rentField.getText();
        String Home1 = HomeField.getText();
        String place1 = placeField.getText();
        String attach1 = attach.getText();

        boolean typeEmpty = type1.isEmpty();
        boolean sizeEmpty = size1.isEmpty();
        boolean rentEmpty = rent1.isEmpty();
        boolean HomeEmpty = Home1.isEmpty();
        boolean placeEmpty = place1.isEmpty();
        boolean attachEmpty = attach1.isEmpty();

        if (e.getSource() == submitButton) {
            if (typeEmpty == false && sizeEmpty == false && rentEmpty == false && HomeEmpty == false
                    && placeEmpty == false && attachEmpty == false) {
                try {
                    int n = Integer.parseInt(rent1);
                    String line = ".\\files\\all_Homes.txt";
                    try {
                        File file = new File(line);
                        if (!file.exists()) {
                            file.createNewFile();
                            FileWriter fileWriter = new FileWriter(file, true);
                            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                            PrintWriter printWriter = new PrintWriter(bufferedWriter);
                            printWriter.close();
                        }

                        BufferedReader readFile3 = new BufferedReader(new FileReader(".\\files\\all_Homes.txt"));
                        int totalLines3 = 0;
                        while (readFile3.readLine() != null) {
                            totalLines3++;
                        }
                        readFile3.close();

                        boolean flag = true;
                        for (int k = 0; k < totalLines3; k++) {

                            String linek = Files.readAllLines(Paths.get(".\\files\\all_Homes.txt")).get(k);
                            if (linek.equals(type1)) {
                                flag = false;
                                break;
                            }

                        }
                        if (flag == true) {
                            String image = "";
                            String p = attach1;
                            char ch;
                            for (int i = attach1.length() - 1; i >= 0; i--) {
                                if (p.charAt(i) == '\\') {
                                    break;
                                } else {
                                    ch = p.charAt(i);
                                    image = ch + image;
                                }
                            }
                            image = "images/" + image;
                            FileWriter fileWriter = new FileWriter(file, true);
                            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                            PrintWriter printWriter = new PrintWriter(bufferedWriter);

                            printWriter.println("Home Details");
                            printWriter.println(type1);
                            printWriter.println(size1);
                            printWriter.println(Home1);
                            printWriter.println(rent1);
                            printWriter.println(place1);
                            printWriter.println(image);
                            printWriter.println();
                            printWriter.close();
                        } else {
                            JOptionPane.showMessageDialog(null, "Same Home already exist", "Error",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                        frame.setVisible(false);
                        new AdminHome();

                    } catch (Exception ex) {
                        System.out.println(ex);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Rent Field", "Error",
                            JOptionPane.WARNING_MESSAGE);
                }

            } else if (typeEmpty == false && sizeEmpty == false && rentEmpty == false && HomeEmpty == false
                    && placeEmpty == false && attachEmpty == true) {
                JOptionPane.showMessageDialog(null, "Please attach a photo", "Error",
                        JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Please fill all the field", "Error",
                        JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == attachButton)

        {
            try {
                JFileChooser chooser = new JFileChooser();
                chooser.showOpenDialog(null);
                File f = chooser.getSelectedFile();
                String filename = f.getAbsolutePath();
                attach.setText(filename);
                imgLabel2.setIcon(new ImageIcon(filename));
                imgLabel2.setBounds(0, 0, 260, 260);

            } catch (Exception ex) {
                return;
            }

        } else if (e.getSource() == exitButton) {
            int yesORno = JOptionPane.showConfirmDialog(null, "Are you sure ?", "Alart!",
                    JOptionPane.YES_NO_OPTION);

            if (yesORno == 0) {
                System.exit(1);
            }
        } else if (e.getSource() == logoutButton) {
            frame.setVisible(false);
            new Login();
        } else if (e.getSource() == backButton) {
            frame.setVisible(false);
            new AdminHome();
        }
    }

}